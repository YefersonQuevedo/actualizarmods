﻿namespace actualizarmods
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonDescargarFtp = new Button();
            labelState = new Label();
            button1 = new Button();
            button2 = new Button();
            label1 = new Label();
            button3 = new Button();
            label2 = new Label();
            label3 = new Label();
            SuspendLayout();
            // 
            // buttonDescargarFtp
            // 
            buttonDescargarFtp.Location = new Point(92, 111);
            buttonDescargarFtp.Name = "buttonDescargarFtp";
            buttonDescargarFtp.Size = new Size(170, 23);
            buttonDescargarFtp.TabIndex = 9;
            buttonDescargarFtp.Text = "Descargar y actualizar Mods";
            buttonDescargarFtp.UseVisualStyleBackColor = true;
            buttonDescargarFtp.Click += button2_Click_1;
            // 
            // labelState
            // 
            labelState.AutoSize = true;
            labelState.Location = new Point(113, 155);
            labelState.Name = "labelState";
            labelState.Size = new Size(120, 15);
            labelState.TabIndex = 10;
            labelState.Text = "Estado de la descarga";
            // 
            // button1
            // 
            button1.Location = new Point(92, 57);
            button1.Name = "button1";
            button1.Size = new Size(170, 23);
            button1.TabIndex = 11;
            button1.Text = "Instalar forge";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(92, 28);
            button2.Name = "button2";
            button2.Size = new Size(170, 23);
            button2.TabIndex = 12;
            button2.Text = "Instalar Java";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(92, 183);
            label1.Name = "label1";
            label1.Size = new Size(170, 15);
            label1.TabIndex = 13;
            label1.Text = "Galaxy Worlds IP: 186.31.27.110";
            // 
            // button3
            // 
            button3.Location = new Point(92, 83);
            button3.Name = "button3";
            button3.Size = new Size(170, 23);
            button3.TabIndex = 14;
            button3.Text = "Instalar SkLauncher";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(25, 209);
            label2.Name = "label2";
            label2.Size = new Size(320, 15);
            label2.TabIndex = 15;
            label2.Text = "Para ejecutar correctamente Mods instala y usa SKLauncher";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(113, 234);
            label3.Name = "label3";
            label3.Size = new Size(112, 15);
            label3.TabIndex = 16;
            label3.Text = "Mods descargados: ";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(461, 274);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(button3);
            Controls.Add(label1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(labelState);
            Controls.Add(buttonDescargarFtp);
            Name = "Form1";
            Text = "Launcher por Fenixdorad0";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button buttonDescargarFtp;
        private Label labelState;
        private Button button1;
        private Button button2;
        private Label label1;
        private Button button3;
        private Label label2;
        private Label label3;
    }
}
